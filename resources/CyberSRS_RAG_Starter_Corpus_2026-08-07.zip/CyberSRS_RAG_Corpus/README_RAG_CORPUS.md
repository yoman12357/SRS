# CyberSRS Starter RAG Corpus

Prepared: 2026-08-07

This package is a curated starter knowledge base for the CyberSRS project. It intentionally separates files that are packaged locally from sources that should be fetched/added separately because they are large, web-native, or have download/redistribution terms that should be checked at the source.

## Recommended repository placement

Copy the `knowledge/` directory from this ZIP into the CyberSRS repository root:

```text
cybersrs/
└── knowledge/
    ├── raw/
    │   ├── nist/
    │   ├── owasp/
    │   ├── mitre/
    │   └── cis_manual/
    ├── metadata/
    ├── manifest.json
    └── manual_sources.json
```

Do not rename source files during ingestion. Store chunk metadata separately and preserve `source_id`, organization, document version, source URL, retrieval date, section/page, and file SHA-256.

## Packaged material

The ZIP includes core NIST guidance, OWASP ASVS 5.0.0 in PDF and CSV, and the OWASP Top 10:2025 introduction.

## Sources intentionally not bundled

`knowledge/manual_sources.json` records additional recommended sources, including the current MITRE Enterprise ATT&CK STIX bundle, OWASP Top 10:2025 category pages, OWASP API Security Top 10:2023, and CIS Controls. These should be fetched from the listed official URLs by your ingestion setup or added manually after checking source terms.

## Important RAG rule

These documents are for retrieval and citation. Do not use the raw standards corpus as the main QLoRA fine-tuning dataset. Fine-tuning should teach requirements-engineering behavior; RAG should provide external cybersecurity knowledge.
